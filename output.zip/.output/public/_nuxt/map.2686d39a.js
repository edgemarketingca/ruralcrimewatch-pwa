import{_ as t}from"./Layout.cfc78d0b.js";import{_,j as c,o as n}from"./entry.5b365ac4.js";const e={};function r(a,s){const o=t;return n(),c(o)}const f=_(e,[["render",r]]);export{f as default};
