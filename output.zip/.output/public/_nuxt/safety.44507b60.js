import{g as u,r as p,o,c as s,F as l,D as y,a as n,G as i,h as c,b as g,d as b,t as h,k as f}from"./entry.5b365ac4.js";const m={id:"accordion-open-heading-1"},v=["onClick"],S={class:"flex items-center gap-2"},k=n("svg",{"data-accordion-icon":"",class:"w-3 h-3 rotate-180 shrink-0","aria-hidden":"true",xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 10 6"},[n("path",{stroke:"currentColor","stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"2",d:"M9 5 5 1 1 5"})],-1),_=["innerHTML"],R=u({__name:"safety",setup(P){const a=[{title:"Personal Safety and Security",icon:"ph:question-duotone",content:`What is Personal Security?

Personal Security involves taking steps to keep yourself safe, and protecting yourself from situations that are potentially violent or criminal. Personal Security is important because property can be replaced but YOU ARE IRREPLACEABLE.

Personal Security involves:

Recognizing, anticipating, and assessing the risk of a crime occurring.
Being aware of your surroundings at all times, and not placing yourself in situations which might jeopardize your safety.
Remember, suspects can be very unpredictable and may have weapons.
When in doubt, CALL POLICE FOR ASSISTANCE
`},{title:"Personal Safety and Security",content:`What is Personal Security?

Personal Security involves taking steps to keep yourself safe, and protecting yourself from situations that are potentially violent or criminal. Personal Security is important because property can be replaced but YOU ARE IRREPLACEABLE.

Personal Security involves:

Recognizing, anticipating, and assessing the risk of a crime occurring.
Being aware of your surroundings at all times, and not placing yourself in situations which might jeopardize your safety.
Remember, suspects can be very unpredictable and may have weapons.
When in doubt, CALL POLICE FOR ASSISTANCE
`},{title:"Personal Safety and Security",content:`What is Personal Security?

Personal Security involves taking steps to keep yourself safe, and protecting yourself from situations that are potentially violent or criminal. Personal Security is important because property can be replaced but YOU ARE IRREPLACEABLE.

Personal Security involves:

Recognizing, anticipating, and assessing the risk of a crime occurring.
Being aware of your surroundings at all times, and not placing yourself in situations which might jeopardize your safety.
Remember, suspects can be very unpredictable and may have weapons.
When in doubt, CALL POLICE FOR ASSISTANCE
`}],r=p();return(w,E)=>{const d=f;return o(),s("div",null,[(o(),s(l,null,y(a,(t,e)=>(o(),s(l,{key:e},[n("h2",m,[n("button",{type:"button",class:i(["flex items-center justify-between w-full p-5 font-medium text-gray-500 border border-gray-300 focus:ring-4 focus:ring-gray-200/0 dark:border-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-900/50 gap-3",[a.length-1===e?"border-b":"border-b-0",{"rounded-t-xl":e===0},{"rounded-b-xl":a.length-1===e&&c(r)!==e}]]),"data-accordion-target":"#accordion-open-body-1","aria-expanded":"true","aria-controls":"accordion-open-body-1",onClick:A=>r.value=e},[n("span",S,[g(d,{class:"w-5 h-5",name:(t==null?void 0:t.icon)??"ph:question-duotone"},null,8,["name"]),b(" "+h(t.title),1)]),k],10,v)]),n("div",{id:"accordion-open-body-1",class:i(c(r)===e?"":"hidden"),"aria-labelledby":"accordion-open-heading-1"},[n("div",{class:i(["dark:text-white p-5 border border-gray-300 dark:border-gray-700 dark:bg-neutral-900",[a.length-1===e&&c(r)===e?"border-b border-t-0 rounded-b-xl":"border-b-0"]])},[n("div",{innerHTML:t.content},null,8,_)],2)],2)],64))),64))])}}});export{R as default};
